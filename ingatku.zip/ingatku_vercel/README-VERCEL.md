# Deploy IngatKu: Vercel + Render

## Kenapa dua layanan?
Frontend HTML/CSS/JS cocok untuk Vercel. Backend IngatKu memakai Python + SQLite, sehingga backend perlu server Python dan penyimpanan persisten. Render dipakai untuk backend agar database SQLite tidak hilang setiap restart/deploy.

## 1. Upload project ke GitHub
Buat repository baru, misalnya `ingatku`, lalu upload seluruh isi folder ini.

## 2. Deploy backend ke Render
1. Buka https://render.com/ dan login dengan GitHub.
2. Pilih **New > Blueprint**.
3. Pilih repository `ingatku`.
4. Render akan membaca `render.yaml`.
5. Deploy `ingatku-backend`.
6. Setelah selesai, salin URL backend, misalnya:
   `https://ingatku-backend.onrender.com`

## 3. Hubungkan frontend ke backend
Buka:
`frontend/js/config.js`

Ubah:
```js
window.INGATKU_API_BASE = '';
```
menjadi:
```js
window.INGATKU_API_BASE = 'https://ingatku-backend.onrender.com';
```
Gunakan URL backend kamu sendiri, tanpa `/` di akhir.

Commit dan push perubahan ke GitHub.

## 4. Deploy frontend ke Vercel
1. Buka https://vercel.com/.
2. Pilih **Add New > Project**.
3. Import repository GitHub `ingatku`.
4. Biarkan framework sebagai **Other**.
5. Build Command: kosongkan.
6. Output Directory: `frontend`.
7. Klik **Deploy**.

Vercel akan memberikan alamat seperti:
`https://ingatku.vercel.app`

## 5. Penting: CORS
Backend sudah memiliki dukungan CORS. Jika backend hanya boleh menerima frontend tertentu, atur environment variable `INGATKU_CORS` di Render ke URL Vercel kamu.

Contoh:
`https://ingatku.vercel.app`

## 6. Lokal di VS Code tetap bisa
Karena `config.js` default kosong, saat lokal frontend tetap menggunakan `/api` dari server Python.

Jalankan:
```powershell
cd backend
python server.py
```
Lalu buka:
`http://localhost:8000`

## Catatan database
SQLite disimpan pada persistent disk Render melalui `render.yaml`. Jangan memindahkan backend SQLite ini ke Vercel Function jika ingin data pengguna tetap tersimpan.
