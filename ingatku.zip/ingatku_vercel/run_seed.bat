@echo off
title IngatKu - Data Demo
cd /d "%~dp0backend"
python seed.py
echo.
echo Data demo berhasil disiapkan.
echo Jalankan run.bat untuk membuka aplikasi.
pause
