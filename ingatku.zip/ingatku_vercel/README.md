# IngatKu — Asisten Memori Suara

Aplikasi web IngatKu terdiri dari **frontend HTML/CSS/JavaScript** dan **backend Python + SQLite**. Proyek ini sudah disiapkan agar mudah dijalankan melalui **Visual Studio Code di Windows**.

## 1. Persyaratan

- Windows 10/11
- Python 3.9 atau lebih baru
- Visual Studio Code
- Ekstensi VS Code **Python** (disarankan)

> Tidak perlu XAMPP, Node.js, atau Live Server. Backend Python sudah sekaligus menyajikan frontend.

## 2. Cara menjalankan di Visual Studio Code

1. Ekstrak ZIP ini.
2. Buka **Visual Studio Code**.
3. Pilih **File → Open Folder**.
4. Pilih folder **ingatku**.
5. Cara paling mudah: klik dua kali file **`run.bat`** dari File Explorer.
6. Atau buka terminal VS Code dan jalankan:

```powershell
cd backend
python server.py
```

7. Buka browser dan masuk ke:

**http://localhost:8000**

### Cara memakai Debug/Run VS Code

Tekan `F5`, lalu pilih konfigurasi:

**IngatKu - Jalankan Server**

Konfigurasi sudah tersedia di `.vscode/launch.json`.

## 3. Menyiapkan akun demo

Jika ingin memakai data contoh:

```powershell
cd backend
python seed.py
python server.py
```

Akun demo:

- Nomor HP: `081234567890`
- Password: `ingatku123`

## 4. Struktur folder

```text
ingatku/
├── .vscode/
│   └── launch.json
├── frontend/
│   ├── index.html
│   ├── css/
│   │   └── style.css
│   └── js/
│       ├── app.js
│       ├── api.js
│       ├── icons.js
│       ├── util.js
│       └── voice.js
├── backend/
│   ├── server.py
│   ├── db.py
│   ├── security.py
│   ├── assistant.py
│   ├── nlu.py
│   ├── voice.py
│   ├── health_content.py
│   ├── seed.py
│   ├── requirements.txt
│   └── tests/
├── run.bat
├── run_seed.bat
└── README.md
```

## 5. Jika `python` tidak dikenali

Coba:

```powershell
py backend/server.py
```

atau pastikan Python sudah ditambahkan ke **PATH** saat instalasi.

## 6. Tes aplikasi

Dari terminal:

```powershell
cd backend
python -m unittest discover -s tests -v
```

Tes proyek yang disertakan berhasil dijalankan.

## 7. Catatan

- Gunakan Chrome atau Edge untuk fitur mikrofon.
- Mikrofon browser bekerja pada `http://localhost` atau HTTPS.
- Fitur suara server (Whisper/TTS) bersifat opsional.
- Database SQLite dibuat otomatis oleh backend.
