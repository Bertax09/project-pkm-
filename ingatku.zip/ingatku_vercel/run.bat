@echo off
title IngatKu - Server
cd /d "%~dp0backend"
echo.
echo ==========================================
echo        INGATKU - SERVER WEB
echo ==========================================
echo.
echo Server: http://localhost:8000
echo Tekan Ctrl+C untuk menghentikan server.
echo.
python server.py
pause
