// URL backend IngatKu.
// Untuk lokal: kosongkan string agar memakai /api.
// Untuk deployment Vercel + Render: isi dengan URL backend Render,
// contoh: https://ingatku-backend.onrender.com
window.INGATKU_API_BASE = '';
